import React from 'react';

const Scan = () => {
  return (
    <div>
      <h2>Scan Component</h2>
      <p>This is the Scan component.</p>
    </div>
  );
};

export default Scan;
