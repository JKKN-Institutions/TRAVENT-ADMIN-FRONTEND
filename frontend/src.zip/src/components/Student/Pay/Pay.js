import React from 'react';

const Pay = () => {
  return (
    <div>
      <h2>Pay Component</h2>
      <p>This is the Pay component.</p>
    </div>
  );
};

export default Pay;

