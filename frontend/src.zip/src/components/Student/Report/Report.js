import React from 'react';

const Report = () => {
  return (
    <div>
      <h2>Report Component</h2>
      <p>This is the Report component.</p>
    </div>
  );
};

export default Report;
