import React from 'react';
import './AppAdminSidebar.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faSchool, faUserShield, faChartBar, faBell, faList, faComments, faUser, faCog } from '@fortawesome/free-solid-svg-icons';

const Sidebar = ({ isOpen, toggleSidebar, setActiveComponent }) => {
  return (
    <div className={`sidebar-container ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <h1>Travent</h1>
      </div>
      <ul className="sidebar-menu">
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('home');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faHome} className="icon" />
            <span>Home</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('manageInstitutions');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faSchool} className="icon" />
            <span>Manage Institutions</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('manageAdmins');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faUserShield} className="icon" />
            <span>Manage Admins</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('reportAnalytics');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faChartBar} className="icon" />
            <span>Report & Analytics</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('notifications');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faBell} className="icon" />
            <span>Notifications</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('activityLogs');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faList} className="icon" />
            <span>User Activity Logs</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('supportFeedback');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faComments} className="icon" />
            <span>Support & Feedback</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('profile');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faUser} className="icon" />
            <span>Profile</span>
          </button>
        </li>
        <li className="menu-item">
          <button 
            className="menu-link" 
            onClick={() => {
              setActiveComponent('settings');
              toggleSidebar();
            }}
          >
            <FontAwesomeIcon icon={faCog} className="icon" />
            <span>Settings</span>
          </button>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
