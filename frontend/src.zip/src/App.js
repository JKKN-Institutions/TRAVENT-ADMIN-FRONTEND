// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AboutApp from './pages/prelogin/AboutApp';
import NewUserForm from './pages/prelogin/NewUserForm';
import AppAdminDashboard from './pages/AppAdmin/AppAdminDashboard/AppAdminDashboard';
import AdminDashboard from './pages/Admin/AdminDashboard/AdminDashboard';
import StaffDashboard from './pages/StaffDashboard/StaffDashboard';
import StudentDashboard from './pages/StudentDashboard/StudentDashboard';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AboutApp />} />
        <Route path="/new-user-form" element={<NewUserForm />} />
        <Route path="/app-admin" element={<AppAdminDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/staff-dashboard" element={<StaffDashboard />} />
        <Route path="/student-dashboard" element={<StudentDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
