// pages/StaffDashboard.js
import React from 'react';

function StaffDashboard() {
  return (
    <div>
      <h1>Staff Dashboard</h1>
      {/* Staff dashboard content */}
    </div>
  );
}

export default StaffDashboard;
