// RecentActivities.js
import React from 'react';
import './RecentActivities.css';

const RecentActivities = ({ data }) => {
    return (
        <div className="recent-activities">
            <h3>Recent Activities</h3>
            <ul>
                {data.map((activity, index) => (
                    <li key={index}>
                        <p>{activity.description}</p>
                        <span>{activity.date}</span>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default RecentActivities;
