
// ManageInstitutions.js
import React, { useState } from 'react';
import './ManageInstitutions.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faBars } from '@fortawesome/free-solid-svg-icons';

const ManageInstitutions = ({ toggleSidebar }) => {
    const [institutions, setInstitutions] = useState([
        {
            id: 1,
            name: 'JKKN Group of Institutions',
            noOfInstitutes: 4,
            createdAt: '2023-06-10',
            updatedAt: '2024-01-15',
        },
        {
            id: 2,
            name: 'PSG Institutions',
            noOfInstitutes: 5,
            createdAt: '2022-08-12',
            updatedAt: '2024-03-01',
        },
    ]);

    const handleEdit = (id) => {
        console.log(`Edit institution with ID: ${id}`);
        // Implement edit functionality here
    };

    const handleDelete = (id) => {
        console.log(`Delete institution with ID: ${id}`);
        // Implement delete functionality here
        setInstitutions(institutions.filter((institution) => institution.id !== id));
    };

    return (
        <div className="manage-institutions-container">
            <div className="top-bar">
                <FontAwesomeIcon icon={faBars} className="menu-icon" onClick={toggleSidebar} />
                <h2>Manage Institution</h2>
            </div>
            <div className="content">
                <table className="institutions-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Institution Name</th>
                            <th>No. of Institutes</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {institutions.map((institution) => (
                            <tr key={institution.id}>
                                <td>{institution.id}</td>
                                <td>{institution.name}</td>
                                <td>{institution.noOfInstitutes}</td>
                                <td>{institution.createdAt}</td>
                                <td>{institution.updatedAt}</td>
                                <td>
                                    <button className="action-button" onClick={() => handleEdit(institution.id)}>
                                        <FontAwesomeIcon icon={faEdit} />
                                    </button>
                                    <button className="action-button" onClick={() => handleDelete(institution.id)}>
                                        <FontAwesomeIcon icon={faTrash} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ManageInstitutions;
