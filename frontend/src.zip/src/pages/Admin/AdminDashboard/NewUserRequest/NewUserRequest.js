import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './NewUserRequest.css';

function NewUserRequest() {
  const [pendingUsers, setPendingUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Fetch pending user requests
    axios.get("http://localhost:3000/api/admin/pending-users")
      .then(response => setPendingUsers(response.data))
      .catch(error => console.error("Error fetching pending users:", error));
  }, []);

  const handleAction = (userId, action) => {
    axios.post("http://localhost:3000/api/admin/approve-user", { userId, action })
      .then(response => {
        alert(response.data.message);
        // Remove the approved/rejected user from the pending list
        setPendingUsers(pendingUsers.filter(user => user._id !== userId));
      })
      .catch(error => console.error("Error handling action:", error));
  };

  // Separate students and staff
  const studentUsers = pendingUsers.filter(user => user.type === "student");
  const staffUsers = pendingUsers.filter(user => user.type === "staff");

  return (
    <div className="new-user-requests">
      <h1>New User Requests</h1>
      <input
        type="text"
        placeholder="Search by Stop Name"
        className="search-input"
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
      />

      {studentUsers.length > 0 && (
        <div className="user-table">
          <h2>Student Table</h2>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Student Name</th>
                  <th>Reg No</th>
                  <th>Roll No</th>
                  <th>Year</th>
                  <th>Department</th>
                  <th>Section</th>
                  <th>Institute Name</th>
                  <th>Stop Name</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {studentUsers.map((user, index) => (
                  <tr key={user._id}>
                    <td>{index + 1}</td>
                    <td>{user.basicDetails.name}</td>
                    <td>{user.studentDetails.regNo || 'N/A'}</td>
                    <td>{user.studentDetails.rollNo || 'N/A'}</td>
                    <td>{user.studentDetails.year || 'N/A'}</td>
                    <td>{user.studentDetails.department || 'N/A'}</td>
                    <td>{user.studentDetails.section || 'N/A'}</td>
                    <td>{user.studentDetails.instituteName || 'N/A'}</td>
                    <td>{user.locationDetails.stopName || 'N/A'}</td>
                    <td>Not Approved</td>
                    <td>
                      <button onClick={() => handleAction(user._id, "approve")}>Approve</button>
                      <button onClick={() => handleAction(user._id, "reject")}>Decline</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {staffUsers.length > 0 && (
        <div className="user-table">
          <h2>Staff Table</h2>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Staff Name</th>
                  <th>Staff ID</th>
                  <th>Institute Name</th>
                  <th>Department</th>
                  <th>Designation</th>
                  <th>Stop Name</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {staffUsers.map((user, index) => (
                  <tr key={user._id}>
                    <td>{index + 1}</td>
                    <td>{user.basicDetails.name}</td>
                    <td>{user.staffDetails.staffId || 'N/A'}</td>
                    <td>{user.staffDetails.instituteName || 'N/A'}</td>
                    <td>{user.staffDetails.department || 'N/A'}</td>
                    <td>{user.staffDetails.designation || 'N/A'}</td>
                    <td>{user.locationDetails.stopName || 'N/A'}</td>
                    <td>Not Approved</td>
                    <td>
                      <button onClick={() => handleAction(user._id, "approve")}>Approve</button>
                      <button onClick={() => handleAction(user._id, "reject")}>Decline</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {studentUsers.length === 0 && staffUsers.length === 0 && (
        <p>No new user requests at the moment.</p>
      )}
    </div>
  );
}

export default NewUserRequest;
