// AdminDashboard.js
import React, { useState } from 'react';
import Sidebar from '../../../components/Shared/Sidebar/Sidebar';
import AdminHome from '../AdminHome/AdminHome';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="dashboard-container">
      <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <AdminHome isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
    </div>
  );
};

export default AdminDashboard;
